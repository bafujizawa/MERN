import axios from 'axios';

export const Search = (props) => {
    // axios.get(`https://swapi.dev/api/starships/9`)
    // .then(res => console.log(res))
}